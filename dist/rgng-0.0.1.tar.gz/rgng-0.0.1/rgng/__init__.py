from .rgng import generate_name
